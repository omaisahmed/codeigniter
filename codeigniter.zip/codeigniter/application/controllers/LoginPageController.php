<?php
class LoginPageController extends CI_Controller
{
	
	public function index()
	{
		
		$this->load->model('LoginPageModel');
		$data['result']=$this->LoginPageModel->login();
		$this->load->view('LoginPage',$data);
	}
			
	}

?>