<?php

class HomeController extends CI_Controller
{
	
	public function index()
	{
		//$this->load->view("blog.php");
		$this->load->view("home.php");
	}
}


?>