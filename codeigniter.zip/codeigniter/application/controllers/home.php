<?php

class Home extends CI_Controller
{
	
	public function index()
	{
		$this->load->view("blog.php");
		$this->load->model("data.php");
		
	}
}


?>