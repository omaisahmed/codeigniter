<?php

class LoginController extends CI_Controller
{
	
	public function index()
	{
		//$this->load->view("blog.php");
		$this->load->view("login.php");
		//$this->load->model("LoginModel.php");
	}
	
	public function CheckLogin(){
		$this->form_validation->set_rules('email','Email','required|valid_email');

		$this->form_validation->set_rules('pass','Pass','required|callback_verifyUser');

		if($this->form_validation->run()==false)
		{
			$this->load->view('login.php');

		}
		else{
            redirect('HomeController/index');
		}
	}
public function verifyUser(){
	$email=$this->input->post('email');
	$pass=$this->input->post('pass');
	$this->load->model('LoginModel');
	if($this->LoginModel->login($email,$pass)){
		return true;
	}
	else{
		$this->form_validation->set_message('verifyUser','Incorrect Email or Password!!!');
	}
}
}


?>