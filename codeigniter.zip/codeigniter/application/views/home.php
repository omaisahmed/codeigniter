<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h1 align="center">Home Page</h1>
<h3>You Have Successfully Logged In!!!</h3>
<a href="../LoginController/index">Logout</a>

</body>
</html>