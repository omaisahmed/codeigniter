<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h1>Login Form</h1>
<?php echo validation_errors(); ?>
<?php echo form_open('LoginController/CheckLogin'); ?>
Username<input type="email" name="email"><br>
Password<input type="password" name="pass"><br>
<input type="submit" value="Login" name="submit">
</form>
</body>
</html>