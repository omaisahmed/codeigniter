<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h1 align="center">Home Page</h1>
<h3>You have Successfully Logined!!!!</h3>
<a href="../LoginPageController/index">Logout</a>
</body>
</html>