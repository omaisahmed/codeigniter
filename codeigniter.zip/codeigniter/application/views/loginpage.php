<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>


<?php 
foreach ($result as $row) {
	echo "<form><table align=center border=1><tr><td>Email</td><td>$row[email]</td></tr><tr><td>Password</td><td>$row[pass]</td></tr></table></form>";
}
?>
</body>
</html>