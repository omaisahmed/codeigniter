<?php
class LoginPageModel extends CI_Model
{
	
	public function login()
	{
		$this->db->select()->from('users');
		$query=$this->db->get();
		return $query->result_array();
	}
}
?>