<?php
/**
 * 
 */
class Data extends CI_Model
{
	
	public function getusers()
	{
		$this->load->database();
		$query = $this->db->query('SELECT firstname, lastname, dateofbirth,email,password,confirmpassword,cnic,mobilenumber ,gender,address,country,city,postalcode FROM myform');

foreach ($query->result_array() as $row)
{
        echo $row['firstname'];
        echo $row['lastname'];
        echo $row['dateofbirth'];
        echo $row['email'];
        echo $row['password'];
        echo $row['confirmpassword'];
        echo $row['cnic'];
        echo $row['mobilenumber'];
        echo $row['gender'];
        echo $row['address'];
        echo $row['country'];
        echo $row['city'];
        echo $row['postalcode'];
}
	}
}
?>